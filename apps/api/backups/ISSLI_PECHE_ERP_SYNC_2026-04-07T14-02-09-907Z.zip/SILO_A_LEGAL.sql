--
-- PostgreSQL database dump
--

\restrict vqm5E37Yh07xOhAMgCqrJaapmhvqz5G4xaB1kTYbDssxZy7fw99CifIGN1TyZWT

-- Dumped from database version 17.7
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.purchase_items DROP CONSTRAINT IF EXISTS "purchase_items_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments_legal DROP CONSTRAINT IF EXISTS payments_legal_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS "invoice_items_invoiceId_fkey";
DROP INDEX IF EXISTS public.suppliers_legal_name_idx;
DROP INDEX IF EXISTS public.suppliers_legal_ice_key;
DROP INDEX IF EXISTS public.suppliers_legal_ice_idx;
DROP INDEX IF EXISTS public.purchase_invoices_supplier_id_idx;
DROP INDEX IF EXISTS public.purchase_invoices_reference_key;
DROP INDEX IF EXISTS public."purchase_invoices_issuedAt_status_idx";
DROP INDEX IF EXISTS public.products_legal_serial_number_key;
DROP INDEX IF EXISTS public.payments_legal_paid_at_idx;
DROP INDEX IF EXISTS public.invoices_reference_key;
DROP INDEX IF EXISTS public."invoices_issuedAt_status_idx";
DROP INDEX IF EXISTS public.invoices_client_id_idx;
DROP INDEX IF EXISTS public.clients_legal_name_idx;
DROP INDEX IF EXISTS public.clients_legal_ice_key;
DROP INDEX IF EXISTS public.clients_legal_ice_idx;
ALTER TABLE IF EXISTS ONLY public.suppliers_legal DROP CONSTRAINT IF EXISTS suppliers_legal_pkey;
ALTER TABLE IF EXISTS ONLY public.quote_sequences DROP CONSTRAINT IF EXISTS quote_sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_items DROP CONSTRAINT IF EXISTS purchase_items_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.products_legal DROP CONSTRAINT IF EXISTS products_legal_pkey;
ALTER TABLE IF EXISTS ONLY public.payments_legal DROP CONSTRAINT IF EXISTS payments_legal_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_sequences DROP CONSTRAINT IF EXISTS invoice_sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS invoice_items_pkey;
ALTER TABLE IF EXISTS ONLY public.company_settings DROP CONSTRAINT IF EXISTS company_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.clients_legal DROP CONSTRAINT IF EXISTS clients_legal_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.suppliers_legal;
DROP TABLE IF EXISTS public.quote_sequences;
DROP TABLE IF EXISTS public.purchase_items;
DROP TABLE IF EXISTS public.purchase_invoices;
DROP TABLE IF EXISTS public.products_legal;
DROP TABLE IF EXISTS public.payments_legal;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.invoice_sequences;
DROP TABLE IF EXISTS public.invoice_items;
DROP TABLE IF EXISTS public.company_settings;
DROP TABLE IF EXISTS public.clients_legal;
DROP TABLE IF EXISTS public._prisma_migrations;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: clients_legal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients_legal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    ice character varying(50),
    address text,
    city character varying(100),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    phone character varying(50),
    if character varying(50),
    rc character varying(50)
);


ALTER TABLE public.clients_legal OWNER TO postgres;

--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_settings (
    id text DEFAULT '1'::text NOT NULL,
    name text DEFAULT 'MA SOCIETE'::text NOT NULL,
    ice text,
    address text,
    phone text,
    email text,
    logo_url text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_settings OWNER TO postgres;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "productName" text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    "unitPriceHT" numeric(10,2) NOT NULL,
    measure_unit text,
    product_id text,
    technical_specs text,
    unit_purchase_cost_snapshot numeric(10,2) DEFAULT 0 NOT NULL,
    vat_rate_snapshot numeric(4,2) DEFAULT 0.20 NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoice_sequences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_sequences (
    year integer NOT NULL,
    "lastCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.invoice_sequences OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    reference text NOT NULL,
    status text DEFAULT 'EN_ATTENTE'::text NOT NULL,
    "totalHT" numeric(12,2) NOT NULL,
    "totalTTC" numeric(12,2) NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'FACTURE'::text NOT NULL,
    client_id text,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    client_address_snapshot text,
    client_ice_snapshot text,
    client_name_snapshot text,
    legacy_reference text,
    note text,
    client_if_snapshot text,
    client_rc_snapshot text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: payments_legal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments_legal (
    id text NOT NULL,
    invoice_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    method text NOT NULL,
    reference text,
    note text,
    paid_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.payments_legal OWNER TO postgres;

--
-- Name: products_legal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_legal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    serial_number text NOT NULL,
    price_ht numeric(10,2) NOT NULL,
    vat_rate numeric(4,2) DEFAULT 0.20 NOT NULL,
    quantity numeric(10,2) DEFAULT 0 NOT NULL,
    "measureUnit" text DEFAULT 'UNIT'::text NOT NULL,
    "technicalSpecs" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    purchase_cost numeric(10,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.products_legal OWNER TO postgres;

--
-- Name: purchase_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_invoices (
    id text NOT NULL,
    reference text NOT NULL,
    supplier_id text NOT NULL,
    status text DEFAULT 'EN_ATTENTE'::text NOT NULL,
    type text DEFAULT 'FACTURE_ACHAT'::text NOT NULL,
    "totalHT" numeric(12,2) NOT NULL,
    "totalTTC" numeric(12,2) NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    note text,
    supplier_name_snapshot text,
    supplier_ice_snapshot text,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_invoices OWNER TO postgres;

--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_items (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    product_id text,
    "productName" text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    "unitPriceHT" numeric(10,2) NOT NULL,
    vat_rate_snapshot numeric(4,2) DEFAULT 0.20 NOT NULL
);


ALTER TABLE public.purchase_items OWNER TO postgres;

--
-- Name: quote_sequences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_sequences (
    year integer NOT NULL,
    "lastCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quote_sequences OWNER TO postgres;

--
-- Name: suppliers_legal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers_legal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    contact_name character varying(255),
    email character varying(255),
    phone character varying(50),
    address text,
    ice character varying(50),
    rc character varying(50),
    if character varying(50),
    patente character varying(50),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.suppliers_legal OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
80f80980-091a-45c9-bd3c-66ba2bb59893	a13a1b7c2578de18129bfd07a33dabf1dfbf453aae7109a2fafa8581213aef9b	2026-03-10 08:11:01.866032+00	20260113152346_sync_legal_invoices	\N	\N	2026-03-10 08:11:01.826851+00	1
c90e10fd-e8eb-4faa-a187-4063766d36b1	a1cd1f4e9508fc9127ec8893f0d39b63b5109fbee8454ea909804da13c294d7d	2026-03-10 08:11:01.87488+00	20260116134738_add_quotes	\N	\N	2026-03-10 08:11:01.866984+00	1
0991bfdf-15ae-4c0c-bcc7-a3bc4f178520	d4d3b771af4d0cdddfd1d8f98b2b3104286dc587a8fa9b2cb3d56a20485a9ef8	2026-03-10 08:11:01.891029+00	20260119153641_add_clients_legal	\N	\N	2026-03-10 08:11:01.876076+00	1
4d340d91-ac98-4f3a-a97f-44f738ba30c7	fca98877c21c2f22963ab1cece0ef40286469281fe87ba60d7c2717e07de76c4	2026-03-10 08:11:01.895268+00	20260119162251_make_ice_optional	\N	\N	2026-03-10 08:11:01.892008+00	1
97b4b6d1-31ee-49a6-9a1b-250f50380fd9	862ad028cd2828e35be03092764d1000ea4332cd1d7598a9e0cb3a6c4275b3f1	2026-03-10 08:11:01.920825+00	20260204182058_add_legacy_reference	\N	\N	2026-03-10 08:11:01.896417+00	1
f5d2067a-9471-4a47-b8c3-b5e4f949539f	a335f27f2195e04a99ac9e34ffd7675623b892ae4bf4e24d6c6b84eca91b2e90	2026-03-10 08:11:01.940527+00	20260211003547_add_legal_fields_and_unique_ice	\N	\N	2026-03-10 08:11:01.922133+00	1
b2b57297-3424-44bb-8e10-1ad191ff109a	fb4b2cf813734eec6581b4846ad9378bcfb27810ef8e1f85c7c7178613759164	2026-03-10 08:11:01.94782+00	20260211003909_fix_client_unique_ice	\N	\N	2026-03-10 08:11:01.941607+00	1
4f6ddffb-0066-4132-ad60-896246d37166	463d904948c8b5ab4f1763f78117001f2bc4a377aa5be9ad45c185d4ab00f3f6	2026-03-10 08:11:01.95167+00	20260211005009_add_invoice_snapshots	\N	\N	2026-03-10 08:11:01.948903+00	1
145f43c3-6d8a-42e9-9133-b3ccb195b9b7	e8cb0bdda7445577af0cbf96aa4fb56487f9f21857243e9f55287f3adce0d279	2026-03-10 08:56:07.463014+00	20260310085607_sync_schema	\N	\N	2026-03-10 08:56:07.455548+00	1
\.


--
-- Data for Name: clients_legal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients_legal (id, name, ice, address, city, created_at, phone, if, rc) FROM stdin;
0d300c5a-df31-45b1-b2f8-ffd23a1e71e1	abc	abc	abc	2	2026-04-07 13:46:51.844	11	\N	\N
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_settings (id, name, ice, address, phone, email, logo_url, "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, "invoiceId", "productName", quantity, "unitPriceHT", measure_unit, product_id, technical_specs, unit_purchase_cost_snapshot, vat_rate_snapshot) FROM stdin;
8cd2c207-0745-4535-9d03-b800732fe142	4d11bc1d-fe73-4ca4-bbef-b61bb6daa9e7	AIGUILLES N 2	1.00	200.00	UNIT	832a1ec1-720b-46f6-8985-c23e4b49b47b		100.00	0.20
\.


--
-- Data for Name: invoice_sequences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_sequences (year, "lastCount") FROM stdin;
2026	1
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, reference, status, "totalHT", "totalTTC", "issuedAt", type, client_id, amount_paid, client_address_snapshot, client_ice_snapshot, client_name_snapshot, legacy_reference, note, client_if_snapshot, client_rc_snapshot) FROM stdin;
4d11bc1d-fe73-4ca4-bbef-b61bb6daa9e7	FAC-2026-0001	PAYEE	200.00	240.00	2026-04-07 13:47:24.134	FACTURE	0d300c5a-df31-45b1-b2f8-ffd23a1e71e1	240.00	abc	abc	abc	\N		\N	\N
\.


--
-- Data for Name: payments_legal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments_legal (id, invoice_id, amount, method, reference, note, paid_at) FROM stdin;
304e88d1-051b-4840-ba6f-495596c8675b	4d11bc1d-fe73-4ca4-bbef-b61bb6daa9e7	240.00	ESPECES		Paiement Comptant	2026-04-07 13:47:24.134
\.


--
-- Data for Name: products_legal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products_legal (id, name, serial_number, price_ht, vat_rate, quantity, "measureUnit", "technicalSpecs", "createdAt", "updatedAt", purchase_cost) FROM stdin;
c5ee009f-5e48-472e-a357-3db5cf888653	ANCRE G.M	IMP-1774630959396-0	0.00	0.10	10.00	UNIT	\N	2026-03-27 17:02:45.241	2026-03-27 17:02:45.241	0.00
326ee171-e9e4-4cb9-9845-3349cba2473c	ANCRE P.M	IMP-1774630959396-1	0.00	0.10	10.00	UNIT	\N	2026-03-27 17:02:45.259	2026-03-27 17:02:45.259	0.00
fac8449e-c3ac-466f-9d37-e6b1e2a39e40	ANCRE	IMP-1774630959396-2	0.00	0.10	10.00	KG	\N	2026-03-27 17:02:45.268	2026-03-27 17:02:45.268	0.00
b55142d3-332e-48c1-83cd-daf9bd9820e4	ANNEAU INOX	IMP-1774630959396-3	0.00	0.10	0.00	UNIT	\N	2026-03-27 17:02:45.274	2026-03-27 17:02:45.274	0.00
a10f31a6-5a70-4ef5-8a2f-623ff0210ca2	AIGUILLES N 3	IMP-1774630959396-5	0.00	0.20	0.00	UNIT	\N	2026-03-27 17:02:45.293	2026-03-27 17:02:45.293	0.00
832a1ec1-720b-46f6-8985-c23e4b49b47b	AIGUILLES N 2	IMP-1774630959396-4	200.00	0.20	9.00	UNIT		2026-03-27 17:02:45.282	2026-04-07 13:47:24.136	100.00
\.


--
-- Data for Name: purchase_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_invoices (id, reference, supplier_id, status, type, "totalHT", "totalTTC", amount_paid, note, supplier_name_snapshot, supplier_ice_snapshot, "issuedAt", "createdAt") FROM stdin;
67e837e3-8d2e-4a5e-afde-8861938bef02	ABC	41357285-ff6f-4afd-a3a9-e05069172b46	EN_ATTENTE	FACTURE_ACHAT	50000.00	55000.00	0.00		TEST	TEST	2026-04-02 03:19:56.007	2026-04-02 03:19:56.007
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_items (id, "invoiceId", product_id, "productName", quantity, "unitPriceHT", vat_rate_snapshot) FROM stdin;
e6b3ca99-8bcc-46b0-80c8-ef991462687f	67e837e3-8d2e-4a5e-afde-8861938bef02	\N	ABC FOR TEST	500.00	100.00	0.10
\.


--
-- Data for Name: quote_sequences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_sequences (year, "lastCount") FROM stdin;
\.


--
-- Data for Name: suppliers_legal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers_legal (id, name, contact_name, email, phone, address, ice, rc, if, patente, created_at, updated_at) FROM stdin;
41357285-ff6f-4afd-a3a9-e05069172b46	TEST	\N		TEST	\N	TEST	TEST		\N	2026-04-02 03:19:06.346	2026-04-02 03:19:06.346
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: clients_legal clients_legal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients_legal
    ADD CONSTRAINT clients_legal_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_pkey PRIMARY KEY (year);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: payments_legal payments_legal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments_legal
    ADD CONSTRAINT payments_legal_pkey PRIMARY KEY (id);


--
-- Name: products_legal products_legal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_legal
    ADD CONSTRAINT products_legal_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: quote_sequences quote_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_sequences
    ADD CONSTRAINT quote_sequences_pkey PRIMARY KEY (year);


--
-- Name: suppliers_legal suppliers_legal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers_legal
    ADD CONSTRAINT suppliers_legal_pkey PRIMARY KEY (id);


--
-- Name: clients_legal_ice_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_legal_ice_idx ON public.clients_legal USING btree (ice);


--
-- Name: clients_legal_ice_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clients_legal_ice_key ON public.clients_legal USING btree (ice);


--
-- Name: clients_legal_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_legal_name_idx ON public.clients_legal USING btree (name);


--
-- Name: invoices_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_client_id_idx ON public.invoices USING btree (client_id);


--
-- Name: invoices_issuedAt_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_issuedAt_status_idx" ON public.invoices USING btree ("issuedAt", status);


--
-- Name: invoices_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX invoices_reference_key ON public.invoices USING btree (reference);


--
-- Name: payments_legal_paid_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_legal_paid_at_idx ON public.payments_legal USING btree (paid_at);


--
-- Name: products_legal_serial_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX products_legal_serial_number_key ON public.products_legal USING btree (serial_number);


--
-- Name: purchase_invoices_issuedAt_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_invoices_issuedAt_status_idx" ON public.purchase_invoices USING btree ("issuedAt", status);


--
-- Name: purchase_invoices_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX purchase_invoices_reference_key ON public.purchase_invoices USING btree (reference);


--
-- Name: purchase_invoices_supplier_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX purchase_invoices_supplier_id_idx ON public.purchase_invoices USING btree (supplier_id);


--
-- Name: suppliers_legal_ice_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX suppliers_legal_ice_idx ON public.suppliers_legal USING btree (ice);


--
-- Name: suppliers_legal_ice_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX suppliers_legal_ice_key ON public.suppliers_legal USING btree (ice);


--
-- Name: suppliers_legal_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX suppliers_legal_name_idx ON public.suppliers_legal USING btree (name);


--
-- Name: invoice_items invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients_legal(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments_legal payments_legal_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments_legal
    ADD CONSTRAINT payments_legal_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_invoices purchase_invoices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers_legal(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_items purchase_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT "purchase_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.purchase_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict vqm5E37Yh07xOhAMgCqrJaapmhvqz5G4xaB1kTYbDssxZy7fw99CifIGN1TyZWT

