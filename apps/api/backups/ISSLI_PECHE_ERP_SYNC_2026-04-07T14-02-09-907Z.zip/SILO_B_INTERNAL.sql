--
-- PostgreSQL database dump
--

\restrict gnsWnpy6SDCMzoRGhMT254RKFmYY7BUyF9Bt4rRaRGWaqDmBcZbY5gKZ3k4RoJg

-- Dumped from database version 17.7
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.purchase_items_internal DROP CONSTRAINT IF EXISTS "purchase_items_internal_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_invoices_internal DROP CONSTRAINT IF EXISTS purchase_invoices_internal_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.movements_internal DROP CONSTRAINT IF EXISTS movements_internal_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.movements_internal DROP CONSTRAINT IF EXISTS movements_internal_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.movements_internal DROP CONSTRAINT IF EXISTS movements_internal_client_id_fkey;
DROP INDEX IF EXISTS public.users_internal_username_key;
DROP INDEX IF EXISTS public.suppliers_internal_name_idx;
DROP INDEX IF EXISTS public.suppliers_internal_ice_key;
DROP INDEX IF EXISTS public.suppliers_internal_ice_idx;
DROP INDEX IF EXISTS public.purchase_invoices_internal_supplier_id_idx;
DROP INDEX IF EXISTS public.purchase_invoices_internal_reference_key;
DROP INDEX IF EXISTS public."purchase_invoices_internal_issuedAt_status_idx";
DROP INDEX IF EXISTS public.products_internal_internal_sku_key;
DROP INDEX IF EXISTS public.movements_internal_product_id_idx;
DROP INDEX IF EXISTS public.movements_internal_created_at_type_idx;
DROP INDEX IF EXISTS public.movements_internal_client_id_idx;
DROP INDEX IF EXISTS public.clients_internal_phone_idx;
DROP INDEX IF EXISTS public.clients_internal_name_idx;
DROP INDEX IF EXISTS public.clients_internal_ice_idx;
DROP INDEX IF EXISTS public.clients_internal_balance_idx;
ALTER TABLE IF EXISTS ONLY public.users_internal DROP CONSTRAINT IF EXISTS users_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers_internal DROP CONSTRAINT IF EXISTS suppliers_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_items_internal DROP CONSTRAINT IF EXISTS purchase_items_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices_internal DROP CONSTRAINT IF EXISTS purchase_invoices_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.products_internal DROP CONSTRAINT IF EXISTS products_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.movements_internal DROP CONSTRAINT IF EXISTS movements_internal_pkey;
ALTER TABLE IF EXISTS ONLY public.clients_internal DROP CONSTRAINT IF EXISTS clients_internal_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users_internal;
DROP TABLE IF EXISTS public.suppliers_internal;
DROP TABLE IF EXISTS public.purchase_items_internal;
DROP TABLE IF EXISTS public.purchase_invoices_internal;
DROP TABLE IF EXISTS public.products_internal;
DROP TABLE IF EXISTS public.movements_internal;
DROP TABLE IF EXISTS public.clients_internal;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."MovementType";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MovementType" AS ENUM (
    'SALE_CASH',
    'RESTOCK',
    'ADJUSTMENT',
    'RETURN',
    'QUOTE',
    'SALE_CREDIT',
    'PAYMENT'
);


ALTER TYPE public."MovementType" OWNER TO postgres;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'LEGAL_USER',
    'POS_USER'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: clients_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients_internal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    category text DEFAULT 'STANDARD'::text NOT NULL,
    notes text,
    total_spent numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    balance numeric(10,2) DEFAULT 0 NOT NULL,
    address text,
    city character varying(100),
    ice character varying(50)
);


ALTER TABLE public.clients_internal OWNER TO postgres;

--
-- Name: movements_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movements_internal (
    id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    type public."MovementType" NOT NULL,
    snapshot_purchase_cost numeric(10,2),
    snapshot_selling_price numeric(10,2),
    amount numeric(10,2),
    user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    snapshot_product_name character varying(255),
    client_id text,
    "paymentMethod" text DEFAULT 'CASH'::text,
    paid_amount numeric(10,2) DEFAULT 0 NOT NULL,
    "paymentRef" text
);


ALTER TABLE public.movements_internal OWNER TO postgres;

--
-- Name: products_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_internal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    internal_sku character varying(50) NOT NULL,
    purchase_cost numeric(10,2) NOT NULL,
    selling_price numeric(10,2) NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "measureUnit" text DEFAULT 'UNIT'::text NOT NULL,
    technical_specs text
);


ALTER TABLE public.products_internal OWNER TO postgres;

--
-- Name: purchase_invoices_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_invoices_internal (
    id text NOT NULL,
    reference text NOT NULL,
    supplier_id text NOT NULL,
    status text DEFAULT 'EN_ATTENTE'::text NOT NULL,
    type text DEFAULT 'FACTURE_ACHAT'::text NOT NULL,
    "totalHT" numeric(12,2) NOT NULL,
    "totalTTC" numeric(12,2) NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    note text,
    supplier_name_snapshot text,
    supplier_ice_snapshot text,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_invoices_internal OWNER TO postgres;

--
-- Name: purchase_items_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_items_internal (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    product_id text,
    "productName" text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    "unitPriceHT" numeric(10,2) NOT NULL,
    vat_rate_snapshot numeric(4,2) DEFAULT 0.20 NOT NULL
);


ALTER TABLE public.purchase_items_internal OWNER TO postgres;

--
-- Name: suppliers_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers_internal (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    contact_name character varying(255),
    email character varying(255),
    phone character varying(50),
    address text,
    ice character varying(50),
    rc character varying(50),
    if character varying(50),
    patente character varying(50),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.suppliers_internal OWNER TO postgres;

--
-- Name: users_internal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_internal (
    id text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'POS_USER'::public."UserRole" NOT NULL
);


ALTER TABLE public.users_internal OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
084269b1-c492-4674-9073-73819675a5a8	140a96943691e14e1bf29dd2f82a8c067ff5cc96fa14774019f7388d682897dc	2026-03-10 08:10:35.191287+00	20260111163738_add_financial_snapshots	\N	\N	2026-03-10 08:10:35.163544+00	1
8c6f9f0b-68dd-4990-b2e5-5d162aa13f96	2f1792fee00d6d46e03f467a12f7173e885f9c698b03e7e780088989f49fbb18	2026-03-10 08:10:35.214286+00	20260118170929_add_3_session_roles	\N	\N	2026-03-10 08:10:35.192569+00	1
e00bdd43-1709-472c-8939-0e914512e0fe	fae2d8c0978a4902c638b9012553f7a7178a0dbcf421925ec458b4a9c9e3cc00	2026-03-10 08:10:35.219039+00	20260119144859_add_quote_type	\N	\N	2026-03-10 08:10:35.215654+00	1
1bb1278b-d859-4d6c-80e8-35b7991580ac	3b298936ecab07dbabaa565919c8e0a86e25cb49ce94c152c2cc42668a85780e	2026-03-10 08:10:35.233795+00	20260119153558_add_clients_internal	\N	\N	2026-03-10 08:10:35.220366+00	1
aeb21723-871d-44e1-9ad8-6ea7c522c87f	eba6cf4df12587010a59e7282d889991bc048e44ba1b16b88d80fa00679afcab	2026-03-10 08:10:35.256453+00	20260120152608_add_credit_system	\N	\N	2026-03-10 08:10:35.234989+00	1
70796f0a-a3f2-4785-b2e4-da87de6b12c4	c91ed8945d0ce91e559573c0a479cf036e3baead29dea1ca045c860c578cc19d	2026-03-10 08:55:47.779845+00	20260310085547_update_movement_enums	\N	\N	2026-03-10 08:55:47.765894+00	1
\.


--
-- Data for Name: clients_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients_internal (id, name, phone, category, notes, total_spent, created_at, updated_at, balance, address, city, ice) FROM stdin;
452f5b81-a8b6-4092-af90-5e01e4846304	TEST	11	STANDARD	\N	100.00	2026-04-02 03:57:43.504	2026-04-02 03:57:56.337	0.00	TEST	\N	TEST
\.


--
-- Data for Name: movements_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movements_internal (id, product_id, quantity, type, snapshot_purchase_cost, snapshot_selling_price, amount, user_id, created_at, snapshot_product_name, client_id, "paymentMethod", paid_amount, "paymentRef") FROM stdin;
194caeee-0bca-49c9-8a22-3e5b8443b68c	bf61fe98-0181-4d28-8970-a53420f44fc4	1	SALE_CASH	100.00	200.00	200.00	cf250ab7-1679-4d79-af0f-bf94c594823a	2026-04-02 03:57:24.248	jh	\N	CASH	200.00	\N
b76586ae-b45c-4fd0-b30e-9bb02ab89381	bf61fe98-0181-4d28-8970-a53420f44fc4	0	PAYMENT	\N	\N	-100.00	cf250ab7-1679-4d79-af0f-bf94c594823a	2026-04-02 03:57:56.332	Règlement Ticket 54701d17	452f5b81-a8b6-4092-af90-5e01e4846304	CASH	100.00	
54701d17-9bea-4527-9a6a-286f31aef6c4	bf61fe98-0181-4d28-8970-a53420f44fc4	0	SALE_CREDIT	0.00	100.00	100.00	cf250ab7-1679-4d79-af0f-bf94c594823a	2026-04-01 00:00:00	[REPRISE DE DETTE] Solde Antérieur	452f5b81-a8b6-4092-af90-5e01e4846304	CREDIT	100.00	DETTE-ANCIENNE
a8c43885-cce8-4eba-8af3-36c5ed659b99	0cdd3fb2-a89b-4285-91ff-99892c023a8d	1	QUOTE	100.00	200.00	200.00	cf250ab7-1679-4d79-af0f-bf94c594823a	2026-04-02 05:12:50.102	AIGUILLES N 3	452f5b81-a8b6-4092-af90-5e01e4846304	CASH	0.00	\N
\.


--
-- Data for Name: products_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products_internal (id, name, internal_sku, purchase_cost, selling_price, quantity, "measureUnit", technical_specs) FROM stdin;
0cdd3fb2-a89b-4285-91ff-99892c023a8d	AIGUILLES N 3	INT-1775106439220-9	100.00	200.00	1297	KG	
2646f1d6-00c1-4781-b1d3-30cb33abe6a3	CABLE EN ACIER D 17	CABLE	0.00	0.00	1	UNIT	\N
60dae7ce-8b4a-459e-a126-97d1cdca83d2	BABORD TREBORD BLANC	INT-1775106439220-53	0.00	0.00	29	UNIT	\N
25ebbe7f-cd2a-48b3-8bc6-6747c7aefd5a	BABORD TREBORD VERT	INT-1775106439220-54	0.00	0.00	28	UNIT	\N
fb2d80d2-8d61-4b18-9b12-e398356a7b39	BABORD TREBORD ROUGE	INT-1775106439220-55	0.00	0.00	10	UNIT	\N
28983b52-9460-4882-82af-d1ff3f3de451	BABORD TREBORD DOUBLE	INT-1775106439220-56	0.00	0.00	9	UNIT	\N
04d6e5bd-1217-4121-b187-2631e98b2093	BABORD TREBORD P21	INT-1775106439220-57	0.00	0.00	30	UNIT	\N
70e9695c-287f-4b3b-ac06-e3db0ff3ddf0	BALANCE ACROC HET 50 KG	BALANCES	0.00	0.00	1	UNIT	\N
02928528-8816-4ef0-bc4f-0d420b3e35c5	ECROU GALVANISEE D 18	QUINCAILLERIE	0.00	0.00	17	UNIT	\N
a582c179-6db6-416b-af09-06952d2db712	BOTTES CHAMEAUX SABOT	BOTTES	0.00	0.00	23	UNIT	\N
bf61fe98-0181-4d28-8970-a53420f44fc4	jh	jh	100.00	200.00	9	UNIT	
ce472a38-ce0e-4cf2-80b4-601a545742ab	Ancre G.M	INT-1775106439220-0	0.00	0.00	18	UNIT	\N
2c5904e6-12e7-4dbd-9802-e5e1f8718bf8	Ancre P.M	INT-1775106439220-1	0.00	0.00	1	UNIT	\N
3712497c-8556-41e0-bdb4-89e767750fc6	Ancre 2.5 KG	INT-1775106439220-2	0.00	0.00	2	UNIT	\N
de3c81b8-6613-479d-b6c8-cae4c73643f7	Ancre 4 KG	INT-1775106439220-3	0.00	0.00	2	UNIT	\N
e574bce1-a056-4471-80d7-347c19963aeb	Ancre 6 KG	INT-1775106439220-4	0.00	0.00	2	UNIT	\N
326163bc-16a2-4e4d-ba29-31093c0c63c5	AIGUILLES N 2	INT-1775106439220-8	0.00	0.00	1837	UNIT	\N
fc0e950c-9277-4477-90bc-91d978dd4b52	AIGUILLES N 200	INT-1775106439220-11	0.00	0.00	12	UNIT	\N
1de128db-6e88-446b-bc74-f19c7d6f0fbe	ACCOMPLIMENT PM	INT-1775106439220-13	0.00	0.00	52	UNIT	\N
64e6e724-1381-4a97-954b-2084e3d9e9e3	ACCOMPLIMENT GM	INT-1775106439220-14	0.00	0.00	17	UNIT	\N
1ca3384c-3c20-4a33-b6a8-1ce8fd5558b4	ACCOMPLIMENT DK	INT-1775106439220-15	0.00	0.00	31	UNIT	\N
e676bcba-b3c5-4091-a708-5d3bde40aaf6	CORDAGE COCO	CORDAGE	0.00	0.00	38	UNIT	\N
2f3f65ee-b501-4ee9-b1ac-911eec240be1	CLOUS CARVEL 14	CLOUS	0.00	0.00	0	UNIT	\N
f3e52c56-7f00-4882-ba5a-a279cce520c1	CACHE ACCOMPLIMENT GM	DROGUERIE	0.00	0.00	6	UNIT	\N
ffe46091-e0b9-4814-a99f-bdcc0dd4af55	COMPAS 75	INT-1775106439220-195	0.00	0.00	6	UNIT	\N
1ee6a0b5-23a9-4b29-bc0a-669699fe8cb6	COMPAS 90	INT-1775106439220-196	0.00	0.00	1	UNIT	\N
77a42e50-d51a-4910-b225-2f185e9f112d	COMPAS 100	INT-1775106439220-197	0.00	0.00	13	UNIT	\N
a73983da-d52a-465f-9b35-3f9545f4d0a2	BOUEE GONFLABLE AVEC PILE	BOUEE	0.00	0.00	5	UNIT	\N
458688e2-80ff-44e1-b002-1b336321ea1d	BOUGIE NGK 1er	INT-1775106439220-34	0.00	0.00	13	UNIT	\N
33b6629e-d502-4175-a245-9ca3f1e0b771	BOUGIE NGK 2eme	INT-1775106439220-35	0.00	0.00	174	UNIT	\N
eece8ff7-4479-42b9-a245-6623f66405ef	BOUGIE YAMAHA	INT-1775106439220-36	0.00	0.00	88	UNIT	\N
acac005a-2f08-4f5d-84ca-d9d9f28fb686	BAGUE ACCOMPLIMENT	INT-1775106439220-38	0.00	0.00	321	UNIT	\N
506e8be0-04c2-4672-933b-7cb99c92a2d9	COMPAS CPSD 20	INT-1775106439221-198	0.00	0.00	11	UNIT	\N
f6d1a3cd-a5e9-49fb-8571-2fab725587a0	COMPAS PLASTIMO 105	INT-1775106439221-199	0.00	0.00	2	UNIT	\N
fe90535a-ee00-4df7-981b-a925c8f583ed	COMPAS PLASTIMO 90	INT-1775106439221-200	0.00	0.00	1	UNIT	\N
f1d017d4-e6ad-41ab-afda-3b9f937d141a	COMPAS GF CUIVRE	INT-1775106439221-201	0.00	0.00	1	UNIT	\N
3501562c-c742-4d97-bc3f-1cb5b1f058da	CHEMISE DK	INT-1775106439221-203	0.00	0.00	1	UNIT	\N
8dd2a4d8-f049-4f60-9f9c-59bc1ada81e2	CHEMISE 150 B	INT-1775106439221-204	0.00	0.00	78	UNIT	\N
6405cc03-7c3e-4801-a843-f3dfa845e77a	CHEMISE 150 A	INT-1775106439221-205	0.00	0.00	263	UNIT	\N
1fa3d207-1916-4e90-b390-c422a0180724	CHEMISE BOUDOUAN	INT-1775106439221-206	0.00	0.00	4	UNIT	\N
991d4300-7cc5-4c92-aa7e-7295e7f8d056	CHEMISE GUASCOR	INT-1775106439221-207	0.00	0.00	130	UNIT	\N
93afefca-46f9-4b85-983f-172de8996c70	GILET NOIR AUTO 150	GILETS	0.00	0.00	16	UNIT	\N
29fda7c8-0a99-4c0d-b9c0-8677e9db9a50	CANNE A PECHE VISION 4	CANNE A PECHE	0.00	0.00	5	1	\N
1b447eb7-1410-4c16-8b60-13f783129cca	COUTEAU EN BOIS	INT-1775106439221-218	0.00	0.00	64	UNIT	\N
6e5446e5-bae6-4393-b156-5da6c9e56026	COUTEAU ORANGE	INT-1775106439221-219	0.00	0.00	144	UNIT	\N
c51fc6f3-8db8-4818-9121-b9bfe2bfb633	COUSSINETS DNP	INT-1775106439221-228	0.00	0.00	323	UNIT	\N
62860d48-818d-4adf-b835-ab8b1f2040e5	COUSSINETS M 26	INT-1775106439221-229	0.00	0.00	451	UNIT	\N
3a6c5b5d-7c50-457c-8ca5-4099377ab31f	COUSSINETS DK	INT-1775106439221-230	0.00	0.00	6	UNIT	\N
965023e4-e6f9-4492-93b0-7678889cf8ed	COUSSINETS GUASCOR	INT-1775106439221-231	0.00	0.00	7	UNIT	\N
54506d5e-811f-46ac-9e13-10fb358e0af0	COUSSINETS BOUDOUAN	INT-1775106439221-232	0.00	0.00	1	UNIT	\N
d36b8710-d1ed-4db7-bb0b-21bb04d5f929	G1	INT-1775106439221-530	0.00	0.00	28	UNIT	\N
6136db25-121e-4e80-b14a-3641fb267d42	G2	INT-1775106439221-531	0.00	0.00	16	UNIT	\N
f47e2c68-77ee-45c3-b5c6-a9429bde167a	O1	INT-1775106439221-532	0.00	0.00	20	UNIT	\N
70027c20-706a-459c-90db-d00ed645a766	O2	INT-1775106439221-533	0.00	0.00	10	UNIT	\N
fa77ed49-5e35-4ee2-be6c-fd751edba1ca	GANTS	GANTS	0.00	0.00	100	UNIT	\N
92529dfa-974e-4075-8c06-70bfd3a7e37f	GUIDE SOUPAPE P15	GUIDE SOUPAPE	0.00	0.00	44	UNIT	\N
3420f2fe-b68a-46c9-a267-6e8e6a353221	MONOFIL 100M 22	MONOFIL	0.00	0.00	25	UNIT	\N
b2c10874-b43f-42aa-b9c3-8981df25f925	LAMPE CALAMAR 500W	LAMPE CALAMAR	0.00	0.00	2	UNIT	\N
090c74ee-08eb-414b-bbde-20abb2046718	FLOTTEUR N 40	FLOTTEUR	0.00	0.00	250	UNIT	\N
28454f80-0e36-40c3-8f7d-0fce14b34d5e	CHAINE INOX D 12	CHAINE	0.00	0.00	0	UNIT	\N
389bab0a-27bc-4089-951d-53a95194ff8a	ETOUPE	ETOUPE	0.00	0.00	0	UNIT	\N
83304c99-cd2f-43bd-942e-69e279f08131	EPOUSSOIR BOIS	EPOUSSOIR	0.00	0.00	15	UNIT	\N
999250bc-1f94-4bcd-b66e-36c6b2be148a	EPOUSSOIR FER	INT-1775106439221-253	0.00	0.00	36	UNIT	\N
38c59af4-761d-4562-953a-9ff18597c64f	PETITE LAMPE BABORD TREBORD	BABORD TREBORD	0.00	0.00	244	UNIT	\N
533b683a-4499-4bfc-8c71-f35ff25bf2ab	PLOMBE LANCE 20	PLOMBE	0.00	0.00	0	UNIT	\N
8e6efd2a-fa6e-46ef-8562-76ec26b2c3c2	EMERILLONS PM 3/0	EMERILLONS	0.00	0.00	956	UNIT	\N
607bd2c2-4205-4f65-85ff-97f625d6b229	FIRIDEAU 80X10	INT-1775106439221-270	0.00	0.00	0	UNIT	\N
ccc98192-e959-4d45-ab18-715dcdc1d2ab	FIRIDEAU 100X10	INT-1775106439221-271	0.00	0.00	0	UNIT	\N
adb5a585-7223-4570-ace2-a3606118cfd0	PEINTURE 1ER	PEINTURE	0.00	0.00	1	UNIT	\N
e026aa53-ee81-490b-b21d-cd81709a6261	FIL NYLON MIFA 30	FIL NYLON	0.00	0.00	0	UNIT	\N
2820e789-96e8-4da4-a7f8-de558d727405	DILUANT 5L	DILUANT	0.00	0.00	1	UNIT	\N
11d54132-f3d3-450a-b596-ae755dd15825	POMPE A EAU MANUELLE	POMPE	0.00	0.00	2	UNIT	\N
4c782e7c-74ea-4303-bbca-48850e277a44	FILET SARDINE MIFA 75X25	FILET SARDINE	0.00	0.00	8	UNIT	\N
b365e670-19d1-4f2f-bcb4-17104b768ed2	FILET CHALUT TERRAIN BLANC 2	FILET CHALUT	0.00	0.00	5	13	\N
97700d4f-e7e9-4964-b47f-50853abad516	HAMECON YOUVELLA S.A 18/0	HAMECON	0.00	0.00	1000	UNIT	\N
b56a444c-a9ea-4e69-a9c2-70a513846159	MANILLE OVALE  31/4 T	MANILLE	0.00	0.00	17	UNIT	\N
46ab5202-f259-4b20-8b5b-1398e6c2c8e0	ENSEMBLE IMPERMEABLE	ENSEMBLES	0.00	0.00	7	UNIT	\N
3c640dc5-56a7-4f24-b90c-5c9df5161d41	FILTRE MITSHUBICHI 45151	FILTRE	0.00	0.00	4	UNIT	\N
de01825a-ab89-48af-97f2-7b730bf1358a	FILET RASHELLE BL	FILET	0.00	0.00	3	UNIT	\N
7b8d7494-0f65-4fd9-a9bb-dd9a42b57e1d	FIL TRESSE PLASTIQUE VERT 1	FIL TRESSE	0.00	0.00	3	UNIT	\N
64dacd1e-e483-4e76-aa1c-468bc1ebb97b	INJECTEUR 949	INJECTEUR	0.00	0.00	2	UNIT	\N
3df82f07-db9d-4f95-be9d-2657a233b38c	FILET TREMAILLE CHINE VERT  9X200	FILET TREMAILLE	0.00	0.00	800	UNIT	\N
afed3cb9-11b4-4e35-95ec-a5a57c1c659d	MAILLETTE 16	MAILLETTE	0.00	0.00	1	UNIT	\N
5016ffb7-460c-4e0e-b52e-448183d160f7	MAILLETTE 18	INT-1775106439222-692	0.00	0.00	3	UNIT	\N
c3caafa6-979d-4b9c-b9f1-b6354c07f444	MAILLETTE 22	INT-1775106439222-693	0.00	0.00	1	UNIT	\N
831a2420-d9c4-41a5-93bc-a18eeb65287b	MAILLETTE 28	INT-1775106439222-694	0.00	0.00	1	UNIT	\N
a3c549ac-1929-4107-827b-0c99a4547eef	MAILLETTE 32	INT-1775106439222-695	0.00	0.00	4	UNIT	\N
47e30d07-adeb-4bf7-9079-68b436ebf256	MAILLETTE 24	INT-1775106439222-696	0.00	0.00	2	UNIT	\N
a98c23ed-aaf7-42e6-8cf6-b6e83885ca37	MAILLETTE 30	INT-1775106439222-697	0.00	0.00	1	UNIT	\N
e94669f3-7044-43b5-a3e3-44347e094694	MIANTE	MIANTE	0.00	0.00	0	UNIT	\N
d02dfd08-68b3-4536-847f-65103169855c	JOINT GUASCOR	JOINT	0.00	0.00	68	UNIT	\N
eb9d3535-b0db-4a51-be3c-2907370ac8b4	KITE	INT-1775106439221-596	0.00	0.00	23	UNIT	\N
4508a5fa-77f1-4966-a405-7908d70f3d62	ATTACHE KIT	INT-1775106439221-597	0.00	0.00	18	UNIT	\N
2983cad5-3adf-443c-a00a-fe71d15c0ed6	LAMPE SOLAIRE	LAMPE	0.00	0.00	67	UNIT	\N
6d6c01f6-b6cd-4621-8156-2f288e27c5ba	PLOT	PLOT	0.00	0.00	2	UNIT	\N
3a3856db-c107-47c8-8172-d854b12dabb7	PLASTIQUE	PLASTIQUE	0.00	0.00	0	UNIT	\N
32b3f4f8-fcef-4870-997c-5ecba7118168	POULIE EN BOIS 3R	POULIE	0.00	0.00	10	UNIT	\N
9ff51bfc-0f98-406b-bebe-01325f36a5bf	PROJECTEUR BLANC	PROJECTEUR	0.00	0.00	2	UNIT	\N
36017c4a-26df-4540-a508-13d8063c04bd	PELLES POIGNET ORANGE	PELLES	0.00	0.00	20	UNIT	\N
23238e48-63c1-4423-8a87-ce8c82de4c00	PIL LASER 2 COULEURS 2 BATTERIE ROUGE-VERT	PIL LASER	0.00	0.00	73	UNIT	\N
74da21e4-84ae-46e1-874d-e47b71099767	POCHETTES OZ	POCHETTES	0.00	0.00	24	UNIT	\N
b42b36a4-7ca2-42f2-bcc7-41df1926c984	RESERVOIR	PIECES MOTEURS	0.00	0.00	2	UNIT	\N
5943caed-ef40-467b-a921-dbd41078f007	PISTON M26/P15	PISTONS	0.00	0.00	11	UNIT	\N
50e88ea3-8281-47e7-a1ba-c4db67aabe1c	VESTE VERT	TENUE DE PECHE	0.00	0.00	12	UNIT	\N
ba2c7dd7-c5a8-4bde-9601-7b5ce65c85c3	RADEAUX GM ROUGE	RADEAUX	0.00	0.00	3	UNIT	\N
455802ee-2db7-4659-97aa-f16ea7aae174	REFLECTEUR RADAR	REFLECTEUR RADAR	0.00	0.00	18	UNIT	\N
dd0196c6-1a65-4fd8-ac92-9c95cf29895c	RAPPALA 18	RAPPALA	0.00	0.00	82	UNIT	\N
58ff15e0-20a9-41e1-8296-934360ba5dc6	RONDELLES INOX 16	RONDELLES	0.00	0.00	45	UNIT	\N
c433a919-f767-46bc-a0b8-023c98c5099f	SULFITE	SULFITE	0.00	0.00	0	UNIT	\N
a253b876-84f0-4850-ac1c-d5dc94be6bb8	SIEGE	SIEGE	0.00	0.00	117	UNIT	\N
ca2176a6-d151-4f96-8dfc-bfd839199d20	SOUPPAPE	SOUPPAPE	0.00	0.00	214	UNIT	\N
cb763234-0510-488f-9a5b-6bc928c9ee4a	SEGMENT  GUASCOR	SEGMENT	0.00	0.00	12	UNIT	\N
b577f352-50c6-46fd-821c-ebbac7ae00cc	TIGE GALVANISEE 12	TIGE	0.00	0.00	2	UNIT	\N
7d66e79e-baff-4f47-a439-30e93401dd46	TUBE GASOIL 16/16 1	TUBE GASOIL	0.00	0.00	2	33	\N
15789cbe-a27d-43ae-b584-27103808772f	TRESSE	TRESSE	0.00	0.00	0	UNIT	\N
6218cc09-233b-438d-ba53-a02d10f6cb44	VINYLON 2EME	VINYLON	0.00	0.00	0	UNIT	\N
88fb0efb-49a5-404b-afc1-f62b1135c8ec	WADERS DUNLOP	WADERS	0.00	0.00	2	UNIT	\N
07521dd1-f9b9-495f-95d9-179875aea4dd	ZING 10 KG	ZING	0.00	0.00	2	UNIT	\N
f6ffb439-d5fb-417b-8cb8-0f03953ddda7	ZING MOTEUR	ZING MOTEUR	0.00	0.00	21	UNIT	\N
8efd14ea-8af8-48d2-99a0-d7ebf0864e15	CASHE ACCOMPLIMENT	CASHE ACCOMPLIMENT	0.00	0.00	0	UNIT	\N
\.


--
-- Data for Name: purchase_invoices_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_invoices_internal (id, reference, supplier_id, status, type, "totalHT", "totalTTC", amount_paid, note, supplier_name_snapshot, supplier_ice_snapshot, "issuedAt", "createdAt") FROM stdin;
05f7b17f-c664-48d9-b45b-638f2058b43f	54	9c87a7d5-d14f-402b-a753-be6f651713f1	EN_ATTENTE	FACTURE_ACHAT	20000.00	22000.00	0.00		test	test 	2026-04-02 03:49:43.296	2026-04-02 03:49:43.296
\.


--
-- Data for Name: purchase_items_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_items_internal (id, "invoiceId", product_id, "productName", quantity, "unitPriceHT", vat_rate_snapshot) FROM stdin;
79276a8b-d182-46c3-adeb-46b9e8100fe6	05f7b17f-c664-48d9-b45b-638f2058b43f	\N	test	100.00	200.00	0.10
\.


--
-- Data for Name: suppliers_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers_internal (id, name, contact_name, email, phone, address, ice, rc, if, patente, created_at, updated_at) FROM stdin;
9c87a7d5-d14f-402b-a753-be6f651713f1	test	\N	\N	test	\N	test 	\N	\N	\N	2026-04-02 03:49:01.186	2026-04-02 03:49:01.186
\.


--
-- Data for Name: users_internal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_internal (id, username, password, role) FROM stdin;
cf250ab7-1679-4d79-af0f-bf94c594823a	admin	$2b$10$P03nHqRa1zZ6FPfiKy0wf.5e/cjEnn2BEAogXghzcIlntlYrFGeOe	SUPER_ADMIN
5fdd23a5-9880-4526-82c7-58cc9d9656c0	legal	$2b$10$P03nHqRa1zZ6FPfiKy0wf.5e/cjEnn2BEAogXghzcIlntlYrFGeOe	LEGAL_USER
33ca6cf5-ffde-4700-8c95-f078ff69bccd	pos	$2b$10$P03nHqRa1zZ6FPfiKy0wf.5e/cjEnn2BEAogXghzcIlntlYrFGeOe	POS_USER
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: clients_internal clients_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients_internal
    ADD CONSTRAINT clients_internal_pkey PRIMARY KEY (id);


--
-- Name: movements_internal movements_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movements_internal
    ADD CONSTRAINT movements_internal_pkey PRIMARY KEY (id);


--
-- Name: products_internal products_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_internal
    ADD CONSTRAINT products_internal_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices_internal purchase_invoices_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_invoices_internal
    ADD CONSTRAINT purchase_invoices_internal_pkey PRIMARY KEY (id);


--
-- Name: purchase_items_internal purchase_items_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items_internal
    ADD CONSTRAINT purchase_items_internal_pkey PRIMARY KEY (id);


--
-- Name: suppliers_internal suppliers_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers_internal
    ADD CONSTRAINT suppliers_internal_pkey PRIMARY KEY (id);


--
-- Name: users_internal users_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_internal
    ADD CONSTRAINT users_internal_pkey PRIMARY KEY (id);


--
-- Name: clients_internal_balance_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_internal_balance_idx ON public.clients_internal USING btree (balance);


--
-- Name: clients_internal_ice_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_internal_ice_idx ON public.clients_internal USING btree (ice);


--
-- Name: clients_internal_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_internal_name_idx ON public.clients_internal USING btree (name);


--
-- Name: clients_internal_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX clients_internal_phone_idx ON public.clients_internal USING btree (phone);


--
-- Name: movements_internal_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movements_internal_client_id_idx ON public.movements_internal USING btree (client_id);


--
-- Name: movements_internal_created_at_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movements_internal_created_at_type_idx ON public.movements_internal USING btree (created_at, type);


--
-- Name: movements_internal_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movements_internal_product_id_idx ON public.movements_internal USING btree (product_id);


--
-- Name: products_internal_internal_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX products_internal_internal_sku_key ON public.products_internal USING btree (internal_sku);


--
-- Name: purchase_invoices_internal_issuedAt_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_invoices_internal_issuedAt_status_idx" ON public.purchase_invoices_internal USING btree ("issuedAt", status);


--
-- Name: purchase_invoices_internal_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX purchase_invoices_internal_reference_key ON public.purchase_invoices_internal USING btree (reference);


--
-- Name: purchase_invoices_internal_supplier_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX purchase_invoices_internal_supplier_id_idx ON public.purchase_invoices_internal USING btree (supplier_id);


--
-- Name: suppliers_internal_ice_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX suppliers_internal_ice_idx ON public.suppliers_internal USING btree (ice);


--
-- Name: suppliers_internal_ice_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX suppliers_internal_ice_key ON public.suppliers_internal USING btree (ice);


--
-- Name: suppliers_internal_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX suppliers_internal_name_idx ON public.suppliers_internal USING btree (name);


--
-- Name: users_internal_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_internal_username_key ON public.users_internal USING btree (username);


--
-- Name: movements_internal movements_internal_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movements_internal
    ADD CONSTRAINT movements_internal_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients_internal(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: movements_internal movements_internal_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movements_internal
    ADD CONSTRAINT movements_internal_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products_internal(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: movements_internal movements_internal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movements_internal
    ADD CONSTRAINT movements_internal_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users_internal(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_invoices_internal purchase_invoices_internal_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_invoices_internal
    ADD CONSTRAINT purchase_invoices_internal_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers_internal(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_items_internal purchase_items_internal_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items_internal
    ADD CONSTRAINT "purchase_items_internal_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.purchase_invoices_internal(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict gnsWnpy6SDCMzoRGhMT254RKFmYY7BUyF9Bt4rRaRGWaqDmBcZbY5gKZ3k4RoJg

